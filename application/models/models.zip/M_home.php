<?php
class M_home extends CI_Model{
   function tampilbarang()
   {
		$this->db->order_by("id","asc");
      $this->db->where('status',true);
		return $this->db->get('mbarang')->result();
   }
   function tampilkategori()
   {
		$this->db->order_by("id","asc");
		return $this->db->get('mkategori')->result();
   }
   function slideshow()
   {
      $this->db->order_by("id","asc");
      return $this->db->get('mslideshow')->result();
   }
}
   
?>